import * as React from 'react';
import { Text, View, StyleSheet, TextInput, Button, Image} from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
    <Card style={styles.carta}>
    <Card style={styles.carta2}>
    <Image style={styles.logo} source={require('./assets/img2.png')} />
    </Card>
      <Text style={styles.titletxt}>
        Altura:
      </Text>
      <TextInput
      style={styles.caixatxt}
      placeholder="Insira sua altura"/>

      <Text style={styles.titletxt}>
        Massa:
      </Text>
      <TextInput
      style={styles.caixatxt}
      placeholder="Insira seu peso"/>

      <Text style={styles.titletxt}>
        IMC:
      </Text>
      <TextInput
      style={styles.caixatxt}
      placeholder="Seu Índice de Massa Corpórea"/>

      <Text style={styles.titletxt}>
        
      </Text>
      
      </Card>
      <Text style={styles.titletxt}>
        
      </Text>
      <Button
      title = "Calcular"
      color = "#007373"
      style={styles.button}
      />
      <Text style={styles.titletxt}>
        
      </Text>
      
      <Button
      title = "Limpar"
      color = "#007373"
      style={styles.button}
      />
     
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#004d4d',
    padding: 8,
  },
  caixatxt: {
    height:30,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    backgroundColor: '#BDD1BD',
    borderTopLeftRadius: 5,
    borderTopRightRadius: 5,
    borderBottomLeftRadius: 5,
    borderBottomRightRadius: 5,
    border: 'double ',
    borderColor:'#040709',
  },
    carta:{
      backgroundColor: '#007373',
    },
    carta2: {
      backgroundColor: '#FFFFFF',
      height: 130,
      width: 150,
      marginTop: 20,
      marginLeft: 90,
      marginBottom: 20,
      border: 'inset',
      borderColor:'#004d4d',
      borderTopLeftRadius: 10,
      borderTopRightRadius: 10,
      borderBottomLeftRadius: 10,
      borderBottomRightRadius: 10,
 
    },
    
    button: {
    borderTopLeftRadius: 5,
    borderTopRightRadius: 5,
    borderBottomLeftRadius: 5,
    borderBottomRightRadius: 5,
    },
     
    logo: {
     height: 120,
     width: 150,
     marginLeft: 0,
     
     },

    titletxt: {
      height: 20,
      marginLeft: 20
    }
});
